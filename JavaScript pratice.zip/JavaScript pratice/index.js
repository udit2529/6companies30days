//for in or for of 
// const a=[1,2,3,4];
// let sum=0;
// for(let i of a){
//     sum+=i;
// }
// console.log(sum);



//const { default: axios } = require("axios");

// const ar=[1,5,3,4];
// let su="";
// for(let i in a){
//    // sum+=i;
//     //print index number
//        su+=ar[i];
//     console.log(i);
// }
// console.log(su);

// const person = {fname:"John", lname:"Doe", age:25}; 
// let txt = "";
// for (let x in person) {
//   txt += person[x] + " " +x +" ";
// }
// console.log(txt);


//closure
//closure helps u to give access outer function scope from inner  function scope 
// function display(){
//     var name ="udit";
//     function nam(){
//         console.log(name);
//         function name2(){
//            // name="tannu"
//             console.log("2"+name)
//             function name3(){
//                 console.log("3"+name)
//             }
//             name="esha"
//             //this name3 will only work when name2 function is call;
//             name3();
//         }
//         name="addy";
//         name2();
//     } 
//     nam();
// }
// //firstly call main function then its call nam function then name 2 then it call name3;
// display();


//map,filter,reduce
//map-helps us to create new array
// const arr=[10,20,30,40,50];
// let a=arr.map((value,index,arr)=>{
//        console.log(value,index,arr);
//       // return value+1;   
//           return value+999; 
// })
// console.log(a);
// console.log(arr);

//filter heps us to give new array as well but with some following condtion
//  
// const arr=[10,20,30,40,50];
// let a=arr.filter((ab)=>{
//        //console.log(ab);
//         return ab<20;  

//         // this types of return is not working in filter;
//       // return value+999; 
//      // return ab-100;
//       //return value*10; 
// })
// console.log(a);
 

//reduce helps us to give single value of whole array
// const arr=[10,20,30,40,50];
// let a=arr.reduce((ab,ba)=>{
//        //console.log(ab+ba);
//         //return ab+ba;  
//          return ab+ba+100;
//         // this types of return is not working in filter;
//       // return value+999; 
//      // return value-100;
//       //return value*10; 
// })
// console.log(a);

//settime and setinterval
//settimeout  allows us run function once after given time of interval
//set interval helps us to repeat function after given interval of time
// function greet(name){
//   console.log("good morning"+ name);
// }
// //this time out fnction gives us id


//  var setid=setTimeout(greet,2000,"udit");
// console.log(setid);
// // helps us cancel excuteion
// clearTimeout(setid);
// var id=setInterval(greet,5000,"esha");
// console.log(id);
// clearTimeout(id);
//setTimeout(greet(),2000,"esha"); wrong function calling ()
 

//slice and splice


// var a=["udit","addy","tannu","sassy","esha"];
//   //var b=a.slice(0,3);
//   // var b=a.slice(3);
//      var b=a.slice(-2,-1);

//   console.log(b);
//   const fruits = ["Banana", "Orange", "Apple", "Mango"];
//   //splice operator return delete value ya add value
//  console.log(fruits.splice(2,3, "Lemon", "Kiwi"));
//  console.log(fruits);

//rest and spread operator
//rest
// function twosum(a,b,...s){
//   console.log(a+b);
//   console.log(s);
// }

// function sum(...args){
//   let total=0;
//   for(let i of args){
//     total+=i;
//   }
//   console.log(args);
//   console.log(total);
// }
// twosum(1,2,3,4,5,6,6,7)
// sum(1,2,3,4,5,6,7,8,9);

//spread 
// let arr=[1,2,3,4,5,6];
// function threesum(x,y,z){
//   console.log(x+y+z);
//   //console.log
// }
// console.log(...arr);
// threesum(...arr);
// //object ke sth spread
// let n={
//   name:"udit",
//   email:"uditmaheshwari17@gmail.com",
//   phone:8766221654,
//   roll:"20201446"
// }

// //overridden 
// console.log({...n,name:"tannu"});
//overiddeen is not working
// console.log({name:"t",...n});

// //object ke sth rest
// const {name,...n1}=n;
// console.log(n1);
// //console.log(name);


// hoisting
// console.log(a);
// greeet("tannu");

// function greeet(nam){
//   console.log(nam);
// }
// var a=9;
// console.log(a)
// //function expressinn and class expression show an error
// console.log(g);
// const g=function(){
//   console.log("hello");
// }
// //const and let are showing error while var is showing undefined
// console.log(a);
// let a=9;

//currying function in js
//when function take multiple arguments in series of function then it take single argumnet
// function sum(a){ 
//   return function(b){
//     return function(c){
//       return function(d){
//         return a+b+c+d;
//       }
//     }
//   }
// }

// const s=sum(7);
// const sum1=s(4);
// const sum2=sum1(5);    
// const sum3=sum2(6);
// console.log(sum3);
// const s1=sum(7)(5)(6)(8);
// console.log(s1);

// //explaination 
// let obj={
//   name:"udit",
//   age:20,
//   email:"uditmaheshwari"
// }
// function user(name){
//   return function(u){
//     return obj[u];
//   }
// }
// let res=user(obj);
// console.log(res('email'));


//call bind apply
// let obj={
//     name:"udit",
//     age:20,
//     email:"uditmaheshwari",
//     printdetails:function(){
//       console.log(this.name);
//     }
//   }
//   print=function(state,country){
//     console.log(this.age+" "+state+" "+country);
//   }
//   print.call(obj,"delhi","india");
//  obj.printdetails();
//   let obj2={
//     name:"tannu",
//     age:20,
//     email:"charcool"
//   }
//   //functin will borrow in call method
//   obj.printdetails.call(obj2);
//  // print.call(obj2,"fbd","india");
// // in apply we pass argumnet in array list
//   print.apply(obj2,["fbd","india"]);

//   // in bind
//  // let v=print.bind(obj2,["fbd","india"]);
//   let v=print.bind(obj2,"fbd","india");
//  // console.log(v);
//   v();


//prototype

//
//  obj={
//   name:"udit",
//   //roll:22,
//   email:function(){
//     return this.name
// },
// getroll:function(){
//   return this.roll;
// }
// }
// console.log(obj);
// let obj2={
//   name:"esha",
//   roll:21,
  //throug this we can obj function and object ke andr ki cheeje
//   __proto__:obj,
//   getcourse:function(){
//     return this.course;
//   }
// }
// console.log(obj2.email());
// console.log(obj2.getroll());

// let obj3={
//  // name:"sassy",
//  roll:23,
//  course:"BCA",
//   //throug this we can obj function and object ke andr ki cheeje
//   __proto__:obj2
// }
// console.log(obj3.getcourse());
// console.log(obj3.getroll());

// /// array have also protypes
// const array=["UDIT"];
// console.log(array)
// // object also prototypes


// const o= new Object();
// console.log(o);

// const arr1=new Array();
// console.log(arr1);

// //how to make prototype property own
// Array.prototype.show=function(){
//   return this;
// }
// const city=["delhi","fbd"];
// console.log(city.show());

// Array.prototype.convertintooje=function(){
//   let obj4={}
//    this.forEach(Element=>{
//     obj4[Element]=Element;
//    });
//    return obj4;
//   }
//   console.log(city.convertintooje());

// //how ro make own prottype
// function myproto(name){
//   return this.name=name;
// }
// const n=new myproto("tannu");
// console.log(n);


//event  loop is helps us to send the function in stack when stack is empty.
// const seconds = new Date().getTime() / 1000;

// setTimeout(() => {
//   // prints out "2", meaning that the callback is not called immediately after 500 milliseconds.
//   console.log(`Ran after ${new Date().getTime() / 1000 - seconds} seconds`);
// }, 500)

// while (true) {
//   if (new Date().getTime() / 1000 - seconds >= 4) {
//     console.log("Good, looped for 2 seconds");
//     break;
//   }
// }
//the execution depends on the number of waiting tasks in the queue.

///firstly basically c1 is going in stack and create a frame or execution in stack
//then set1 is going in stack and create a frame and execution and send to wep api,
//then c2 is going in stack and create a frame or execution in stack
//then set 2 is going in stack abd create a frame and send to web api
// after completeing the time in wep api then it goes into queue and waiting in the queue 
//once queue is empty then this qurur task goes into 
//thn console is working in 
// (() => {

//   console.log('this is the start');

//   setTimeout(() => {
//     console.log('Callback 1: this is a msg from call back');
//   }); // has a default time value of 0

//   console.log('this is just a message');

//   setTimeout(() => {
//     console.log('Callback 2: this is a msg from call back');
//   }, 0);

//   console.log('this is the end');

// })();
//async example
// const fun2=()=>{
//   setTimeout(()=>{
//     console.log("event loop checking");
//   },5000);
// }
// const fun1=()=>{
//   console.log("hello there");
//   fun2();
//   console.log("hello there is part 2");
// }
// fun1();

//sync example
// const fun2=()=>{
//   // setTimeout(()=>{
//     console.log("event loop checking");
//   // },5000);
// }
// const fun1=()=>{
//   console.log("hello there");
//   fun2();
//   console.log("hello there is part 2");
// }
// fun1();

//promoise 
//promoise helps to notify wheter that function is resoled and rejected.
// let promise= new Promise(function(resolve,reject){
//   console.log("function is resolved");
//  // resolve(56);
//   reject();
// })

// function getData(){
//   setTimeout(()=>{
//     console.log("hey this is set interval");
//   },2000);
// }
// console.log(promise);
// getData();

// let p1 = new Promise(function(resolve,resject){
//   console.log("promise is started")
//   setTimeout(()=>{
//     console.log("hey this is set interval of 2 sec");
//    resolve(true);
//    // reject(new err("i am error"));
//   },2000);
// })
// let p2= new Promise(function(resolve,reject){
//   console.log("promise is started")
//   setTimeout(()=>{
//     console.log("hey this is set interval of 5 sec");
//    // resolve(true);
//     reject(new Error("i am error"));
//   },5000);
// })
// // to get the value
// 
//callbacks
// const studnets=[
//   {name:"udit",subject:"cs"}
// ]

// function enroll(studnet,callback){
//   setTimeout(()=>{
//     studnets.push(studnet);
//     callback();
//   },5000)
// }
//  function getstudents(){
//   let str="";
//   setTimeout(()=>{
//     studnets.forEach(function(studnet){
//       str+= `${studnets.name}`
//         })
        
//   },1000)
//  }

//  let newstudent=[{name:"esha",subject:"unpadh"}];
//  enroll(newstudent);
// // getstudents()
//  console.log(studnets)

//async awiat
// async function harry(){
//     let delhi= new Promise( (resolve,rejec) => {
//         setTimeout(()=>{
//         console.log("Dehi temperature");
//         resolve(27);
//       },2000) 
// });
// let fbd= new Promise( (resolve,rejec) => {
//   setTimeout(()=>{
//   console.log("fbd temperature");
//   resolve(21);
// },5000) 
// });
//         delhi.then((value)=>{
//               console.log(value);
//         })
//         fbd.then((value)=>{
//           console.log(value);
//     })
//     console.log("delhi is ready")
//       let d= await delhi ;
//       console.log("delhi is end")
//       console.log("fbd is ready")
//       let f= await fbd;
//       console.log("fbd is end")
//       return[d,f];
// };
// console.log("weather is fetching");
// let a=harry();

//  async function cherry(){
//   await console.log("hello this is cheery")
// };
// let  b=  cherry();
// console.log(a);
// console.log(b);
// a.then((value)=>{
// console.log(value);
// });

//debucing means barbar apni api nd function ko call naa kra jaaye uske blade kis time of inteval  ke bd call kra jaaye
// let count=0;
// function getdata(){
//   console.log("fetching data"+count++);
// }
// function debounce(g,d){
//   let timer;
//   return function(...args){
//   if (timer)
//   // when we habe time 5 sec in in set timeout but then we start tping before 5 sec of completion
//   // then time will cLEAR AND START WORKING AGAIN

//   clearTimeout(timer);
//   setTimeout(()=>{
//          g();
//   },d)
//   }
// }
// debounce(getdata,2000);

//throtle
// const throtle=((fn,d)=>{
//      return function(...args){
//      document.getElementById("btn").disabled=true;
//      setTimeout(()=>{
//       fn();
//      },d)
//     }
// });

// const best=throtle(()=>{
//   document.getElementById("btn").disabled=false;
//   console.log("user clicked");
// },5000)


// 

///api fetch
//how to fetch data in api

//

// const ctodo= async(todo)=>{
//   /// this is post option helpa us to fetch details from erver to console of browser
//   let option={
//     methods:"POST",
//     headers:{
//       "Content-type":"Application/json"
//     },
//     // pass data in json format means js objects into json formAT
//     body:'JSON.stringify(todo),
// }
// // API FECTHING
//      let p= fetch('https://jsonplaceholder.typicode.com/todos/1');
//      let r= (await p).json()
//       return r;
// }

// // ANOTHER API FETCHING
// const gettodo= async(id)=>{
//   let p= fetch('https://jsonplaceholder.typicode.com/todos/1'+id);
//   let r= (await p).json()
//   return r;
// }
// // PASS DATA TO CHECK ITS IS PRESENT IN API OR NOT
// const main=async()=>{
//    let todo={
//     title:"udit",
//     email:"uditmaheshwari",
//     userid:2
//    }
//    let todor=await ctodo(todo);
//    console.log(todor);
//    console.log(await gettodo(2));
// }
// //CALLING MAIN FUNCTION TO CHECK IT IS PRESNET OR NOT
// main()


//get in axios
// axios.get("https://reqres.in/api/users?page=2")
// .then((res)=>console.log(res))
// .catch((err)=>console.log(err))
// post in axios
// axios.post("https://reqres.in/api/users",{
//   name:"udit",
//   job:"software developer"
// })
// .then((res)=>console.log(res))
// .catch((err)=>console.log(err))
// // put in axios
// axios.put("https://reqres.in/api/users/2",{
//   name:"esha",
//   job:"software developer"
// })
// .then((res)=>console.log(res))
// .catch((err)=>console.log(err))

//delete in axios
// axios.delete("https://reqres.in/api/users/2")
// .then((res)=>console.log(res))
// .catch((err)=>console.log(err))


